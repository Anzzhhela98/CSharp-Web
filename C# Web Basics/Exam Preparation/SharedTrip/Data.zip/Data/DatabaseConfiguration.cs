﻿namespace SharedTrip.Data
{
    public class DatabaseConfiguration
    {
        public const string ConnectionString =
            @"Server=.;Database=SharedTrip;Trusted_Connection=True;Integrated Security=True;";
    }
}